# FlipperAmiibosNFC
Amiibo dump of .nfc files that will work on emulators like Flipper Zero.

Put any of these directly in the "nfc" folder on your SD Card. 

*FYI: Some Amiibos require write access to the emulated key, Flipper doesn't support this as of now so not all Amiibos will function fully.*
